---
category: link
date: 2014-04-12 16:07
layout: post
source-link: http://www.pewresearch.org/next-america/
title: The Next America
---
Paul Taylor, writing for the Pew Research Center: 

> At a time when young and old don’t look alike, think alike or vote alike, how will America modernize its entitlement programs so they're in sync with its new demographics? How can we keep faith with the old without bankrupting the young and starving the future? It will be difficult.

This is an excellent example of data analysis and narrative, packaged in a beautiful, responsive web design. 