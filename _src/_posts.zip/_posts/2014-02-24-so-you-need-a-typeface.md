---
title: So You Need a Typeface
date: 2014-02-24 16:01
layout: post
category: post
---
Using Julian Hansen's famous [typeface-related poster](http://julianhansen.com/index.php?/alternative-type-finder/) as a starting point, Ian Li built [an interactive version](http://ianli.com/synat/) that retains the same charm as the original.

I like Li's version (it's certainly easier to navigate), but Hansen's is great because I can work my way backwards through the logic tree, starting with a typeface instead of its eventual application.