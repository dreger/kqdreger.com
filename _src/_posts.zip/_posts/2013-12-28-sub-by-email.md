---
title: Subscribe by Email
date: 2013-12-28 16:31
layout: post
category: post
---
Today, I'm happy to announce that you can subscribe to this site's posts via email. Subscribe-by-email has been one of the most requested features I've received over the past few months, and I'm happy to finally be able to provide the service. If you head over to the [Subscribe page](/feeds), you can  submit your email to get started. As of now, posts will be sent once a day, whenever there are new posts.

If anyone has any feedback on this new system, please don't hesitate to [contact me](/colophon).