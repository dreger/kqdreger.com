---
title: Dear Ms. Tina Brown
date: 2014-03-12 12:36
layout: post
category: post
---
_I tried to sending the following message through the [Tina Brown Media](http://www.tinabrownmedia.com/contact-us/) contact form, but the message wouldn't send (I assume it was exceeding the server's maximum number of allowed characters). Nonetheless, the remarks I am addressing took place publicly, so I feel the apology should as well._

---

Ms. Brown,

Forgive me for using the contact form intended for Women in the World, but I was unable to find any means of contacting you specifically, other than Twitter, which I avoided because of its informal nature.

Just last night, on March 12, you spoke at the University of Mount Union as the guest speaker for their annual Schooler Lecture Series. It was a wonderful evening, and the whole campus appreciated you taking the time to spend a day with us.

I am emailing you to sincerely apologize. Last night, when I got the chance to ask you a question during the lecture ("do you plan to expand Women in the World to other areas of international news" / "where do you stand on the oxford comma"), I addressed you as "Tina" and not, as I should have, "Ms. Brown."

The warm, friendly nature of the onstage discussion gave me an unintentional assumed familiarity with you, and I am sorry.

Respect and accuracy matters, as you said last night, and I wanted to make sure you know that I regard you as one of the most well-spoken, intelligent individuals in the media today. I have nothing but admiration for your work, and I sincerely hope that my gaffe in public was not taken as a lack of respect towards you or your accomplishments.

I tried to catch you after our short meeting at President Giese's house, but I didn't get a chance to speak with you privately before you left. Nonetheless, I wanted to make sure I got the chance to apologize and to take an extra opportunity to thank you for visiting. I wish you all the luck with the Women in the World Summit this April, and I will be following the coverage in the news closely.

Thank you again,

Kyle Dreger


