---
title: The Log Podcast
date: 2014-02-19 21:09
layout: post
category: post
---
Last night, I flipped the switch on my latest project, [The Log Podcast](/log) [1].

I really can't tell you just _how_ excited I am to launch this. Not only has daily readership of the site reached a point where I'm comfortable to start branching out into different mediums, but I now have a way of reaching my readers through a medium I have a great passion for: public speaking. For the past few months I had been working out the logistics of getting a podcast up and running, and finally being able to get something out there feels great.

Instead of writing too much more about the show, I would recommend you go listen to the [pilot episode]({% post_url log/2014-02-18-pilot %}). Although my audio occasionally gets a little high (I was excited), the following episodes should fix that issue. Once you've finished, please do not hesitate to [let me know](/colophon) what you think.

Thank you for being with me on the journey so far, and here's to another chapter.

Thanks for reading _and_ listening,<br>
KD

---

1. Although I like "The Log" &mdash; it hearkens back to the days of a "captain's log" &mdash; I'm still toying with the final name for the podcast. Any thoughts?