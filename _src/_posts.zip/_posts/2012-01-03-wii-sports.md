---
layout: post
category: post
title: Wii Sports
---

My family owns a Wii. However, we only own one game - Wii Sports.

I love Wii Sports, it's brilliant. Although it was primarily created as a way to show new Wii users the basics of the then-new interaction between the Wii remotes and gameplay, many of the games are incredibly addictive and well designed. In an area where Nintendo could have just included a tutorial, they chose to build something really awesome.

I'm sure at some point my family will get another Wii game, I've been eyeing up Mario Kart Wii, but for now we have fun with Wii Sports. It's a great game and a nice tribute to what putting in quality effort can do for your users. Thanks, Nintendo.