---
category: link
date: 2014-05-21 19:23
layout: post
source-link: http://voiceandtone.com
title: Voice and Tone
---
The rhetorical style guide for the writers at digital-newsletter company, MailChimp: 

> Before you write content for MailChimp, it’s important to think about our readers. Though our voice doesn’t change, our tone adapts to our users’ feelings.

Even with short, one-sentence copy, it is critical to understand the context of your users' emotions and state of mind. More companies should have documents like this. 