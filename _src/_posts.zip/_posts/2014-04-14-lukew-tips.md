---
category: link
date: 2014-04-14 11:58
layout: post
source-link: https://storify.com/bombayhustle/lukew-tips-for-mobile-design
title: Tips for Mobile Design
---
A collection of usability and user experience tweets from design veteran, [Luke Wroblewski](http://www.lukew.com/about/). If you design for mobile screens, check these out. 