---
title: Try Things
date: 2014-04-14 12:20
layout: post
category: post
published: false
---
The long and short of it is this: I'm retiring The Log. 

It has been fun, I've really enjoyed publishing the nine episdoes. But there has been another revelation as well. 
