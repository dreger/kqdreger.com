---
title: Football as Football
link: http://www.footballasfootball.com
date: 2013-11-19 20:49
layout: post
category: post
---
American football logos redesigned for European football clubs. Easily one of the best sites I've seen this month &mdash; I particularly love the Browns's badge.