---
title: The Nifty MiniDrive
date: 2014-02-18 09:27
layout: post
category: post
---
The [Nifty MiniDrive](http://theniftyminidrive.com) is a new, 64GB SD card available for the Macbook. Although there is no shortage of [SD cards available on Amazon](http://www.amazon.com/s/?_encoding=UTF8&camp=1789&creative=390957&field-keywords=64gb%20sd%20card&linkCode=ur2&sprefix=64gb%20sd%2Celectronics%2C358&tag=kyldre-20&url=search-alias%3Delectronics) [affiliate link], the MiniDrive is shorter than a standard SD card, which means that, once inserted, it will remain flush against the side, instead of protruding out. 

Nifty is currently selling the 64GB card (in black or red) for $39.99 and will throw in a free 2GB card with every order. 