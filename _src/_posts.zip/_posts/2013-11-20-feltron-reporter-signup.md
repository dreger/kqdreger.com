---
title: Reporter for iPhone
link: http://www.reporter-app.com
date: 2013-11-20 14:38
layout: post
category: post
---
Nicholas Feltron, the guy behind those [incredibly-detailed self analysis reports](http://feltron.com/ar12_01.html), is getting ready to release Reporter for iPhone, a data-collecting tool that helps you track the quantifiable data in your life. From the pre-launch page:

> Reporter is a new application for tracking the things you care about. With a few randomly timed surveys each day, Reporter can illuminate aspects of your life that might be otherwise unmeasurable.

Sign me up.
