---
title: "Skim PDF Reader for Mac"
link: http://skim-app.sourceforge.net
date: 2013-10-30 14:41
layout: post
category: post
---
I'm currently in the middle of reading through 30 research-heavy PDFs and needed a way to extract the text I highlighted while reading. A little bit of searching later and I found Skim. It does exactly what I wanted and has made my life much easier. If you do any sort of research and deal with lots of PDFs, go get Skim right now.