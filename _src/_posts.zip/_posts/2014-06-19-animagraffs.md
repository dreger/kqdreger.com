---
category: link
date: 2014-06-19 21:45
layout: post
source-link: http://animagraffs.com
title: Animagraffs; Not Your Average Gif
---
Truly incredible animations of complex mechanisms by Jacob O'Neal. 