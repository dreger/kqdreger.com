---
layout: post
category: post
title: GORUCK GR1 Delivered
date: 2012-06-19
---

My GORUCK GR1 arrived today.

I want to write a longer review after I get done dragging it through Georgia next week, but here are some quick impressions:

<!-- more -->

- Damn this is a nice bag. I'm 5'8″, weigh around 150 and this bag fits great. My previous Radio Ruck was a good fit, but the GR1 really hugs my body with all my gear in it.
- The GR1 can fit a ton, the pockets are deep and the slightly angled bottom keeps the weight higher on my back. I needed some extra space, and it delivers.
- It looks great. Any color, so long as it's black.
- After just a couple hours, you can tell this bag exudes quality. Every detail was thought out, and anything that wasn't needed was cut out. This leaves you with a minimalistic piece of gear that performs at a high level.

Only having it a few hours, I'm not afraid to say this is the last bag I will ever buy. The Radio Ruck will be great for a lot of people, but for my college student athlete needs, and a love of traveling, this bag is perfect.