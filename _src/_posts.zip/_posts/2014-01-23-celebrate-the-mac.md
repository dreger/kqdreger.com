---
title: Celebrate The Mac
date: 2014-01-23 18:03
layout: post
category: post
---
Tomorrow will mark 30 years since Steve Jobs first unveiled the original Macintosh ([video](https://www.youtube.com/watch?v=2B-XwPjn9YY)). To help celebrate, Jonathan Zufi, the man behind the ICONIC Book I linked to a while back, has created a website called [Celebrate The Mac](http://www.celebratethemac.com) where he has uploaded high-quality photographs of nearly every Mac from the past 30 years. Personally, my favorites are from his ["classic" collection](http://www.celebratethemac.com/classic). 

Compared to [some of the competitors of the time](http://www.hpmuseum.net/exhibit.php?class=1&cat=41), it is not hard to see why the Macintosh's design was considered beautiful. 