---
title: Give Your Resume A Face Lift
link: http://www.lifeclever.com/give-your-resume-a-face-lift/
date: 2013-11-19 20:10
layout: post
category: post
---
Wow. Even though this post from Chanpory Rith dates back to 2006, his advice is still incredibly practical for the job seekers of today. A must read for anyone who's looking to create their own resume.