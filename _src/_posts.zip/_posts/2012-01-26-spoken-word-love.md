---
layout: post
category: post
title: Spoken word "Love"
category: Spoken word
tags: love, poetry, praise
---

Had an interesting reflection experience.

I felt really inspired after watching [some of Jeff Bethke's videos](http://www.youtube.com/user/bball1989). I took this inspiration, along with my Macbook, and went to the BnB cafe. I grabbed a drink, sat down and took some quiet time to clear my mind. What I ended up doing was writing my first “spoken word” poetry piece. I really liked how it turned out, so I got creative and even [made a video](http://youtu.be/ZPvXsyCDYs0) for it. It was a really great way for me to reflect; I felt in the zone and was really surprised at how refreshed I felt afterwards. Hopefully this is the start of something new for me.

> Abstinence is hard / And no, that's not a pun / In fact the fight against temptation / Is the farthest thing from fun.
>
> But He never puts us where / He's knows we can't succeed / Just don't try to fight alone / For only through Him are we freed.
>
> True grace comes from devotion / We have the armor of our Lord / But if you close your heart and ignore His word / You'll fall on your own sword.
>
> So guys, lead with grace / I know she feels like your life / But respect her how you'd want another man / to respect your future wife.
>
> Dear Lord keep us joyful / As we go our separate ways / May our minds remain on you / To give you ever-constant praise
>
> Let us be bold for your message / You already paid the cost / Keep our convictions to you strong / When we're surrounded by the lost.
>
> And let us lead them to you / To seek your mercy from above / For leading the lost to Jesus / Is the truest definition of love.