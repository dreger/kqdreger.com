---
title: Vesper Support Guidelines
link: http://vesperapp.co/blog/support-guidelines/
date: 2013-11-05 13:24
layout: post
category: post
---
Over on the Q Branch blog, Dave Wiskus wrote about how he approaches support for Vesper:

> Contacting support is part of the experience of using Vesper, so how can we design this part of the experience with the same care and consideration we put into the software itself?

Wiskus has some excellent guidelines listed, and for me &mdash; as a customer &mdash; seeing these types of posts reaffirm how [much I love this app]({% post_url 2013-07-13-vesper %}).