---
layout: post
category: post
title: New cleats
date: 2012-06-12
---

Short one today. I got my new soccer cleats today - Adidas Predator Absolions. I use to wear Predators all the time when I was younger, but once I got into my sophomore year of high school, I switched to Pumas. Ever since then, I had bought the same pair of Puma shoes off eBay, or wherever I could find them; they were the perfect size and fit. However, after all these years, it's finally time to return and give adidas another go.

So far, I love having a little more protection on my feet – I tend to get stepped on a lot, and the Predators have a little more padding than the Pumas – and the touch is nice and soft. I'm looking forward to breaking them in.