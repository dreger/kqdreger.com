---
title: That'll Be $1,850
date: 2014-01-21 20:35
layout: post
category: post
---
[Brent Simmons](http://inessential.com), a Mac and iOS developer, recently received an email from his domain registrar, Network Solutions, informing him that his account [had been automatically enrolled into a new security program](http://inessential.com/2014/01/21/network_solutions_auto-enroll_1_850), WebLock, and that his credit card would "be billed $1,850 for the first year of service." 

Read that again. A company opted-in a customer to a program that costs over $1,500 a year, and they only informed him after the deed was done. 

Utterly appalling. 
