---
category: link
date: 2014-05-08 17:42
layout: post
source-link: https://itunes.apple.com/app/litely/id850707754
title: Litely for iOS
published: false
---
It seems like there is no shortage of camera-replacement applications on the App Store. However, every once in a while, a new one will pop up that grabs my interest. The latest is Litely, from Cole Rise and Sam Soffes. 

I linked to Rise's work back in my 