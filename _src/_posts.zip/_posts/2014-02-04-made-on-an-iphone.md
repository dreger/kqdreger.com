---
title: Made on an iPhone
date: 2014-02-04 18:00 -5
layout: post
category: post
---
Apple, on their [new "1.24.14 Film" page](http://www.apple.com/30-years/1-24-14-film/):

> On January 24, 1984, Apple introduced the Macintosh. And with it a promise that the power of technology, put in the hands of everyone, could change the world. On January 24, 2014, we sent 15 camera crews all over the world to show how that promise has become a reality.

The whole video was shot using the iPhone 5s' built-in camera, compiled on a Mac, and then scored with an original soundtrack &mdash; in one day. 100 iPhones were used to shoot the, over, 70 hours of footage.

This may be yet _another_ video of Apple showing how great it is to use their products, but I think what they are subtly trying to say is that the original creativity and personality the Mac remains unchanged to this day.