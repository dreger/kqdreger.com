---
title: The World Press Photo Awards
date: 2014-02-15 17:15
layout: post
category: post
---
5,754 photographers, from 132 nationalities, took over 98,000 photographs for [the 57th World Press Photo Contest](http://www.worldpressphoto.org/awards/2014).

Striking, raw looks at humanity.