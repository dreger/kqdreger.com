---
title: Mactracker.app
date: 2014-01-23 18:53
layout: post
category: post
---
Writing my last post, I was trying to remember the name of an app I had used that listed the details and specifications of not just every Mac, but also every Apple _device_ ever made. A little searching and I finally found it: [Mactracker by Ian Page](http://mactracker.ca). 

Page has versions of Mactracker available for [OS X](https://itunes.apple.com/app/mactracker/id430255202?mt=12) and [iOS](http://itunes.apple.com/app/mactracker/id311421597?mt=8), and both versions are completely free. This is a fantastic little app, and it provides a great way to look at Apple's history of products, in entirety, from the beginning to the present. 