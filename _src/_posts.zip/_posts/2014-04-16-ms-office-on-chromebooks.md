---
category: link
date: 2014-04-16 19:54
layout: post
source-link: http://www.computerworld.com/s/article/9247681/Microsoft_concedes_Chromebooks_are_work_worthy
title: Microsoft and 
published: false
---
