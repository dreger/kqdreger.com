---
title: Reporter for iPhone Released
date: 2014-02-06 14:53
layout: post
category: post
---
Earlier this morning, Reporter for iPhone was officially released [on the App Store](https://itunes.apple.com/us/app/reporter-app/id779697486?ls=1&mt=8). Reporter, the brainchild of data-analyst [Nicholas Feltron](http://feltron.com), randomly presents you with lightweight surveys throughout the day, and then compiles that data into fascinating personal reports. At just $3.99 cheap, this will be one of the first apps I buy when I am off my [digital media hiatus]({% post_url 2014-01-15-things-i-could-have-bought %}).