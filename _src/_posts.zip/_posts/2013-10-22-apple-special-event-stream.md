---
title: Live Stream of Today's Apple Event
link: http://www.apple.com/apple-events/october-2013/
date: 2013-10-22 12:48
layout: post
category: post
---
For the first in a very long time, Apple has a live stream of today's event available. However, you'll need a Mac, iOS device, or Apple TV to catch it:

> Live Streaming video requires Safari 4 or later on OS X v10.6 or later; Safari on iOS 4.2 or later. Streaming via Apple TV requires second- or third-generation Apple TV with software 5.0.2 or later.

If you don't meet the requirements, definitely check out liveblogs from [The Verge](http://www.theverge.com/2013/10/21/4861774/live-coverage-apple-ipad-5-event), [Macworld](http://live.macworld.com/2013/10/iPadEvent/index.php), and [Engadget](http://www.engadget.com/2013/10/22/apple-liveblog/) for the latest.