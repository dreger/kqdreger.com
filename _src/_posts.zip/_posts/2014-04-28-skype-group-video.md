---
category: link
date: 2014-04-28 11:13
layout: post
source-link: http://blogs.skype.com/2014/04/28/skype-loves-bringing-groups-together-with-free-group-video-calling/
title: Skype Makes Group Video Calling Free
---
Phillip Snalune, writing on the Skype company blog: 

> For the last few years, we’ve offered group video calling to Premium users on Windows desktop and Mac and more recently Xbox One. Today, we’re excited to announce that we’re making group video calling free – for all users on these platforms. And, in the future, we’ll be enabling group video calling for all our users across more platforms – at no cost.

If group video is your thing, it's great to _finally_ have a free alternative to Google Hangouts and its (sometimes problematic) web interface. 