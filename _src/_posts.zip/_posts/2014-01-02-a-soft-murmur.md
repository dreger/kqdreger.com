---
title: A Soft Murmur
date: 2014-01-02 13:44
layout: post
category: post
---
I write better with background noise, and lately, I've been enjoying the [ambient noise from A Soft Murmur](http://asoftmurmur.com). This site allows you to generate an array of background sounds by adjusting the volume levels of six different sounds: rain, thunder, fire, waves, birds, and humans.

I have a nice library of instrumental music tracks in iTunes, but I've been listening to a lot of A Soft Murmur lately. Bonus: it works great on iOS as well.