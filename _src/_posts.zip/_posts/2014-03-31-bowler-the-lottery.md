---
title: Scratch-Off Media
date: 2014-03-31 21:46
layout: post
category: post
---
Chris Bowler, with some thoughtful reflection on the effects of [getting everything in real time](http://chrisbowler.com/journal/the-lottery): 

> But the real problem here is not the technology itself, but our perception of value. We've elevated the mundane to the top of our priority list and allowed the possibility of news from someone else to take precedence over our own work. That scares me.

