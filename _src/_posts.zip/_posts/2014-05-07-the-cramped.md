---
category: link
date: 2014-05-07 21:40
layout: post
source-link: http://www.thecramped.com/about/
title: "The Cramped"
---
Patrick Rhone, one of my favorite online writers, just started a new site called _The Cramped_:

> If you are the sort of person who appreciates nice paper, a decent pen, a well-crafted notebook, a solid pencil, writing and receiving handwritten correspondence, beautiful handwriting, or the clicky-clack of a dependable typewriter, you have come to the right place. The Cramped is a site dedicated to the pleasures of writing with analog tools (the name is purposefully ironic).

One particularly interesting feature of _The Cramped_: Rhone occasionally includeds a [scanned image of his hand-written drafts](https://dl.dropboxusercontent.com/u/1575/perfectnotebook-draft.pdf) to accompany their digital counterparts. This adds a fantastic personal touch to the narrative Rhone is going for.
