---
category: link
date: 2014-05-28 18:17
layout: post
source-link: http://youtu.be/t9cmoT_wb0A
title: "Coca-Cola Presents: The Friendly Twist"
---
Coca-Cola made bottles that require two bottles to open. I'm not a big pop drinker, but this video from might be one of the coolest (and quirkiest) things I've seen from a soft-drink company.
