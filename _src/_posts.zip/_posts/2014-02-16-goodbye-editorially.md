---
title: Goodbye, Editorially
date: 2014-02-16 21:03
layout: post
category: post
---
Editorially, the collaborative online writing application, is shutting down on May 30. From [their Goodbye post](http://stet.editorially.com/articles/goodbye/):

> We’re proud of the team and tool that we built together and incredibly thankful that so many of you were willing to give it a try. And we continue to believe that evolving the way we collaborate as writers and editors is important work. But Editorially has failed to attract enough users to be sustainable, and we cannot honestly say we have reason to expect that to change.

> We wish that were not the case — we’ve spent much of the past two years working on the hypothesis that the reverse was true — but today we must be honest with ourselves, and with you: this isn’t going to work.

Editorially got a lot of things right, and the tools they had built were something that I truly enjoyed using to collaborate with other editors and writers. Sad news.