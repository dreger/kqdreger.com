---
category: link
date: 2014-04-22 23:05
layout: post
source-link: https://appleseed.apple.com/sp/betaprogram/learn
title: Apple OS X Beta Program
---

Apple: 

> The OS X Beta Seed Program gives users the opportunity to run pre-release software. Test-drive beta software and provide quality and usability feedback that will help make OS X even better.

This is pretty big news. Before today, you had to have an Apple Developer account ($99 a year) to download and install the pre-release betas of OS X on your Macs. Now, anyone can do it for free &mdash; just be sure to back-up your system before doing so.

If this beta-seeding program goes well, I wonder if Apple would ever expand it to including pre-release versions of iOS? 