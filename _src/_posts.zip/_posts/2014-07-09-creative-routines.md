---
category: link
date: 2014-07-09 21:26
layout: post
source-link: https://podio.com/site/creative-routines
title: Daily Routines of Creative People
---
Fascinating. 
