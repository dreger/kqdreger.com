---
title: "Mavericks Update for Mail.app and Gmail"
link: http://support.apple.com/kb/DL1703
date: 2013-11-09 14:19
layout: post
category: post
---
If you've recently upgraded to OS X Mavericks and found that Mail.app was a doing an increasingly-poor job at managing your mail, I encourage you to go download this patch from Apple which fixes those issues.

Between the popularity of Gmail and Mail.app being a core OS X application, I really can't believe they didn't catch these issues in the beta releases.