---
title: Some stats from KDHQ
date: 2013-10-24 08:04
layout: post
category: post
---
The past few weeks at the KDHQ have been fun, and I want to share some stats and updates.

_Note: all statistics derived from data collected between Sep. 2 and Oct. 24 of 2013._

### Traffic
- Highest traffic in a single day: 50 unique visitors
- Total pageviews: 1,816

### Posts statistics
- 11 articles written
- 17 items linked to
- 7,299 words written

### Operating System Breakdowns
- iOS: 36.5%
- Windows: 35.3%
- Mac: 23.5%
- Android: 3.1%
- Windows Phone: .7%

### Countries that have visited
- United States
- Canada
- Brazil
- South Africa
- Germany
- France
- Spain
- Portugal
- United Kingdom
- Italy
- Sweden
- India
- Russia
- Ukraine
- Kazakhstan
- Malaysia
- Philippines
- Japan
- Australia
- New Zealand

Not too shabby for the first two months. Remember that you can [contact me](http://kyledreger.com/contact) with any questions. Thanks for reading.


