---
layout: post
category: post
title: Goodbye, Facebook
date: 2012-02-02 19:30 -5
---

It started with one text from my girlfriend. The message read:

> byebye facebook

Strong words coming from her, but I got excited. Leaving Facebook was an idea I have been toying with for quite a while now, but never had the motivation to actually do. Here now was my opportunity, and I decided to take it it.

There were some real reasons for keeping my profile active, namely that I am the sole admin/developer for several pages and applications. However, after taking some time to transfer ownerships to other individuals (namely our office's "social" account so I can still do my job), I'm free and clear.

I'm looking forward to seeing what the effects of not owning a Facebook identity are. Facebook, having become a part of my generation's DNA and about to file for a [record-breaking IPO](http://www.nytimes.com/2012/02/02/technology/for-founders-to-decorators-facebook-riches.html), it will be weird to watch everything happen from the outside. However, it's about time I started removing some of the things that distract me from real life. Emily and I have a bet that the first one to log back in owes the other dinner, but after only *an hour* into this hiatus, I don't know whether we'll ever see a winner.

Sometime's it's nice to be outside.