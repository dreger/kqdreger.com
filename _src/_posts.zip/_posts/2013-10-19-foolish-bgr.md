---
title: "Foolish Reporting of the Week: Brad Reed"
link: http://bgr.com/2013/10/18/apple-ios-7-lawsuit-filed/
date: 2013-10-19 18:42
layout: post
category: post
---
Brad Reed, writing for _BGR_, wins this week's _Foolish Reporting_ award for his ridiculously misleading headline writing. The headline in question? "iPhone user hates iOS 7 so much that he's suing Apple over it":

> Brighter colors and flat icons just aren't for everybody. That said, it seems that iPhone user Mark Menacher hates them much more than anyone else. CNET reports that Menacher has actually filed a suit against Apple in small claims court and is asking the company to let him remove the iOS 7 install file from his iOS devices.

Everything in this article would have you believe that Menacher hates iOS 7 so much that he's willing to sue Tim Cook over it. But that's a lie. From the [original article on the case](http://news.cnet.com/8301-13579_3-57608171-37/apple-taken-to-court-over-unwanted-ios-7-install-download/) by Josh Lowensohn for _CNET_:

> Mark Menacher, a resident of Poway, Calif., filed [a small-claims complaint](http://courtindex.sdcourt.ca.gov/CISPublic/casedetail?casenum=201300313457&casesite=KM&applcode=C) against Apple's CEO Tim Cook in the Superior Court of California in San Diego on Thursday, asking for the removal of the iOS 7 install file -- something that's downloaded to devices automatically when they're connected to power and a Wi-Fi connection.

iOS 7 didn't even install on Menacher's device, so how could he hate it? He never said he did. Rather, he's upset that the installer file takes up more than 1 GB of space and was downloaded automatically &mdash; a legitimate complaint.