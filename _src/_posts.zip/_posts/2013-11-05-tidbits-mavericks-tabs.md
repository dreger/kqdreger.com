---
title: Using Tabs in the Mavericks Finder
link: http://tidbits.com/article/14260
date: 2013-11-05 08:59
layout: post
category: post
---
Great collection of tips. Also useful if you've forgotten that the Finder can now create tabs.