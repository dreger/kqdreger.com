---
category: link
date: 2014-04-17 21:46
layout: post
source-link: http://recode.net/2014/04/17/facebooks-nearby-friends-feature-aims-for-more-offline-hook-ups/
title: Facebook Launches "Nearby Friends"
---
Very similar to Apple's [Find My Friends app](https://www.apple.com/apps/find-my-friends/), but powered by your existing Facebook network. The feature is explicitly opt-in, which should help placate some of the, inevitable, privacy-focused backlash.