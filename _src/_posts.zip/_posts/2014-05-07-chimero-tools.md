---
category: link
date: 2014-05-07 21:55
layout: post
source-link: 
title: Using the Right Tools
published: false
---
Frank Chimero: 

> My world is laden with bad tools, because my culture is simultaneously obsessed with productivity and novelty. It is a perfect vector for fixation, because the failure of a tool only feeds the desire for new tools. Meaning, I get to feel honorable in my vigilant search for productivity while scratching my itch for novelty.

A flawed tool you know is better than a new tool you don't. 