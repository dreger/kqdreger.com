---
category: link
date: 2014-04-21 21:47
layout: post
source-link: http://recode.net/2014/04/18/beats-bites-the-bullet-and-starts-selling-subscriptions-from-apples-app/
title: Giving up 30% to Sell In-App iOS Subscriptions
---
Peter Kafka, writing for _Re/code_: 

> Beats updated its iPhone app today, and now lets users subscribe to the $10 a month service from within the app, using iTunes' billing system. That means Beats, and the music labels that license their stuff to the service, will give up $3 a month on every subscription sold through iTunes.

Beats Music is willing to take a 30% hit _just_ to sell their same subscription, but through an in-app purchase dialog. Speaks volumes about the purchasing power of iOS users. 