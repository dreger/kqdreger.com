---
title: Big Cartel Guides
date: 2014-03-14 22:34
layout: post
category: post
---
Big Cartel, the makers of a customizable online store for your creative goods, has a [delightful micro-site](http://guides.bigcartel.com) that features small guides filled with "Practical advice for everything you may encounter throughout your life as an artist and entrepreneur."

Each guide is short, informative, and well designed. My favorites were the ones on [product photography](http://guides.bigcartel.com/product-photography/), [copyright](http://guides.bigcartel.com/copyright), and [taxes](http://guides.bigcartel.com/taxes/). 