---
title: "'For Immediate Release'"
date: 2014-01-18 18:49
layout: post
category: post
---
Yesterday, Hoefler &amp; Co. [issued a public statement](http://typography.com/press/20140117) in regards to Tobias Frere-Jones suing Jonathan Hoefler. The company's General Counsel, Michael Burke:

> Last week, designer Tobias Frere-Jones, a longtime employee of The Hoefler Type Foundry, Inc. (d/b/a "Hoefler & Frere-Jones"), decided to leave the company. With Tobias's departure, the company founded by Jonathan Hoefler in 1989 will become known as Hoefler & Co. ...


> It goes without saying that all of us are disappointed by Tobias's actions. The company will vigorously defend itself against these allegations, which are false and without legal merit. In the meantime, we're all hard at work, continuing to create the kinds of typefaces that designers have come to expect from us for more than 25 years.

Frere-Jones sues for $20 million dollars. Hoefler changes the company name. Until both parties go to trial, it is going to be near impossible to understand what really went on here.

