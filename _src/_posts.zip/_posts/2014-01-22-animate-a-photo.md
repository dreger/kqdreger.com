---
title: How to Animate a Photo, The 2.5D Effect
date: 2014-01-22 22:31
layout: post
category: post
---
Joe Fellows, the founder of [Make Productions](http://www.makeproductions.co.uk) (a short film and production company), shows [how he creates the effect of motion in still photographs](http://vimeo.com/79329423), a la _parallax_. The whole process, from photo shoot to post-production, is fascinating, and the end result is undeniably mesmerizing. 