---
category: link
date: 2014-06-19 21:53
layout: post
source-link: https://www.youtube.com/watch?v=L0DsvpE9aOk
title: "My Mom's Motorcycle"
---
Douglas Gautraud: 

> This is a short film about how my mom became the owner of a motorcycle for the My Rode Reel competition. More deeply it is about how people use objects to connect with times, ideas, and people. 

Polished, funny, and creative non-fiction storytelling at its very finest. 