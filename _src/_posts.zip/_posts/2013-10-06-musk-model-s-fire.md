---
title: Elon Musk on Model S Fire
link: http://www.teslamotors.com/blog/model-s-fire
date: 2013-10-06 10:57
layout: post
category: post
---
After numerous reports [and videos](http://www.youtube.com/watch?v=q0kjI08n4fg) of a Telsa Model S being on fire at the end of a highway off-ramp, Telsa C.E.O. Elon Musk commented on the company blog:

>The Model S owner was nonetheless able to exit the highway as instructed by the onboard alert system, bring the car to a stop and depart the vehicle without injury. [...] For consumers concerned about fire risk, there should be absolutely zero doubt that it is safer to power a car with a battery than a large tank of highly flammable liquid.

As pointed out by [John Gruber](http://daringfireball.net/linked/2013/10/04/musk-model-s), Musk and Telsa have a beautifully-clear, plain laguage they use when writing these types of posts; it goes a long way in building trust with consumers.