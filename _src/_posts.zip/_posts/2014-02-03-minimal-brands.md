---
title: Minimizing Brands
date: 2014-02-03 10:32
layout: post
category: post
---
Mehmet Gozetlik, the founder of design collective [Antrepo](http://www.a2591.com/), has taken 17 well-known brands and [reduced their products' branding to the bare minimal](http://www.thedieline.com/blog/2011/11/10/a-study-in-brand-minimalism.html). Although I think consumers would quickly tire of _everything_ being set in Helvetica, I do like how Gozetlik favored printing directly on the glass or plastic instead of using a paper wrapper.