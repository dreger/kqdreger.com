---
category: link
date: 2014-05-13 13:00
layout: post
source-link: https://www.youtube.com/watch?v=I78OflS6hWc
title: Yours Truly, Speaking at Mount Union's Graduation
---
Three days ago, I graduated from the University of Mount Union. As the president of the Class of 2014, I had the distinct pleasure of giving the closing speech for our graduation ceremony, and the response has been overwhelming. To all those who reached out, for all the kind words and wishes, I give a heartfelt "thank you," and I feel incredibly blessed to have such good friends and family. 

I also want to thank all the readers of this site. Posting should get back to normal this week, but I want to offer my thanks for all the support and feedback I have received over the past year. I have some exciting things lined up for kyledreger.com in the future, and I owe it all to you, the readers, for helping make this journey possible. 

Thanks, as always, for reading. 

KD