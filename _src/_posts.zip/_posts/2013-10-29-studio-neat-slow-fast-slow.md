---
title: Slow Fast Slow by Studio Neat
link: http://www.studioneat.com/products/slowfast
date: 2013-10-29 13:14
layout: post
category: post
---
One of the great features of the iPhone 5S' camera is the ability to take 120 fps (frames per second) video and then play it back in slow motion. Unfortunately, that feature is exclusive to the iPhone 5S.

Thankfully, the folks at Studio Neat have released an app called Slow Fast Slow which brings slo-mo video capabilities to the iPhone 5/5C/5S and iPod Touch (5th generation). The UI looks fantastic and much more usable than Apple's own interface in Camera.app.

Studio Neat is the company behind a great stop-motion video app, [Frameographer](http://www.studioneat.com/products/frameographer), and they also make one of the best iPad styli around, the [Cosmonaut](http://www.studioneat.com/products/cosmonaut).