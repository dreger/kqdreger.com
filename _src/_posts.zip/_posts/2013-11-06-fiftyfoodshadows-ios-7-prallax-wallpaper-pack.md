---
title: Fiftyfootshadows.net iOS 7 Parallax Wallpaper Pack
link: http://fiftyfootshadows.net/2013/11/06/ios-7-parallax-wallpaper-pack/
date: 2013-11-06 08:33
layout: post
category: post
---
John Carey:

> Well, it took me a little longer than I had expected but here we go. The fiftyfootshadows parallax wallpaper pack for iOS devices running iOS 7. After quite a bit of research and trial and error I have settled on what I believe to be the optimal resolutions for iOS 7. Barring any major changes these images should leave you set for a good long while.

Carey has two sets of 30 images (for iPad and iPhone) available right now on his post for free, and he's also got 100-image collections for each device available at just $7 apiece, or $10 if you want both. All images are cropped a little bigger than the device's screen, meaning the parallax-tilt effect will work fine.

Carey's site was one of my [top places to get great desktop wallpapers](%{ post_url 2013-09-15-great-desktop-wallpaper-sources %}), and today he's raised his own bar even higher. I'll be switching wallpapers for the rest of the day now, if only I could choose which one I like the best.