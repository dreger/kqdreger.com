---
title: Betteridge's Law of Headlines
link: http://en.wikipedia.org/wiki/Betteridge's_law_of_headlines
date: 2013-11-05 08:32
layout: post
category: post
---
Speaking of [dishonest reporting]({% post_url 2013-10-19-foolish-bgr %}), Ian Betteridge has a simple way to quickly filter through most of the sensationalist news out there today:

> Any headline which ends in a question mark can be answered by the word no.

Through personal experience, this has been proven correct time and time again.