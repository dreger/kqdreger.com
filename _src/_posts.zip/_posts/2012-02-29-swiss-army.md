---
layout: post
category: post
title: Swiss Army
---

I love Swiss Army knives. When I was a kid, I had a red-handled one that had all the essential things a boy on a small farm needed. I used to spend hours whittling away at sticks, or tightening up the screws on my toys and bike. More than once, the tweezers were brought out to get a microscopic splinter out of my palm. I used the heck out of that thing and it always found a place in my pocket.

Then one day, when I was 14, I misplaced it. To this day I haven't been able to find it. I later received a small, camo-clad hunting knife for Christmas from our family friends. It served my purposes for the time, but I still missed the versatility of my old knife.

Yesterday as I was browsing Amazon, I saw that they had a sale going on - Take $10 off your Swiss Army knife purchase! - and I took that as a sign. After searching the models, I decided on the ["Tinker"](http://amzn.com/B0007QCOB0). I like the small number of tools and that it comes in a black paint. I'm expecting it to arrive sometime today, it will be great to have an old friend back in my bag.