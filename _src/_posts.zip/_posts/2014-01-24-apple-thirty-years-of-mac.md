---
title: "Apple: Thirty Years of Mac"
date: 2014-01-24 14:10
layout: post
category: post
---
Featuring a two-minute video, interactive timeline, and high-quality images of (nearly) every Macintosh, Apple's new mini-site [pays beautiful respect to the past 30 years of the Mac](https://www.apple.com/30-years/). 