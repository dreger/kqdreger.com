---
category: link
date: 2014-05-22 22:25
layout: post
source-link: http://www.nytimes.com/interactive/2014/upshot/buy-rent-calculator.html?_r=2
title: Better to Rent or Buy?
---
Aimed at those who are looking to invest in a house, the _New York Times_ has updated their fantastic "Rent or Buy" calculator. Not only is the new version more sophisticated (with over 20 different variables you can adjust), but it is also a great example of vector-based, interactive graphing done right on the web.
