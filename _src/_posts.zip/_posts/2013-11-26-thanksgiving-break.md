---
title: Thanksgiving Break
date: 2013-11-26 09:52
layout: post
category: post
---
My Thanksgiving break begins today after classes finish at 5 p.m. Given that the next few days will be filled with food, family, and traveling, KDHQ will be happily shutting down our web browsers until next week. 

I hope each of you have a blessed and safe holiday, and I ask everyone to be careful while traveling as Winter Storm "Boreas" [looks to drop plenty of snow and ice](http://www.weather.com/news/weather-winter/winter-storm-boreas-southwest-texas-oklahoma-kansas-northeast-20131122) in the Eastern United States. Might be time to [unleash those hoodies]({% post_url 2012-02-19-hoodies %}) if you haven't already.