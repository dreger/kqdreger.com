---
category: link
date: 2014-06-19 21:49
layout: post
source-link: http://www.creativebloq.com/computer-arts/80-years-world-cup-ticket-designs-61411991
title: The Past 80 Years of World Cup Ticket Design
---
Both the 1958 (Sweeden) and 1966 (England) designs are fantastic. If I had to pick one, it would be Sweeden's for the great serif numerals. 