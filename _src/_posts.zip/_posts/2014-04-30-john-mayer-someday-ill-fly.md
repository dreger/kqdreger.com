---
category: link
date: 2014-04-30 16:24
layout: post
source-link: http://vimeo.com/91168154
title: "John Mayer: Someday I'll Fly"
---
Eastwood Allen:  

> Someday I'll Fly chronicles the musical evolution of one of the most influential solo artists of his generation. Featuring rare demos, interviews and live performances; it is told in it's entirety from Mayer's perspective.
> 
> This is a fan-made, nonprofit documentary that utilises archived television interviews, podcasts, bootleg recordings, Internet clips, album tracks, DVD and Blu-ray footage in an effort to showcase John Mayer's career in music.

This *fan-made* documentary is one of the best _documentaries_ I've ever watched. Near perfection. 