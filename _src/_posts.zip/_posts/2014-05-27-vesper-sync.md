---
category: link
date: 2014-05-28 08:18
layout: post
source-link: http://vesperapp.co/blog/vesper-2-0-and-vesper-sync/
title: Vesper Sync
---
John Gruber, writing over on the [Vesper blog](http://vesperapp.co/blog/), announcing Vesper 2.0 with Vesper Syncing:

> There is no charge. No subscription. You just create an account using your email address as your identity and it works.

Vesper remains my [note-taking app of choice]({% post_url 2013-07-13-vesper %}), and this is a great update. But what's next for Vesper? To my joy, a Mac client; Gruber:

> We have several ideas for future Vesper clients, but we’ve decided which one we’re going to tackle next: Mac. We did the iPhone version first because the iPhone is the one device you have with you everywhere, and we remain convinced that was the correct decision. Ubiquity is essential to a notes app. The Mac, though, is the device where we’re most productive.

Color me excited.
