---
title: Life is a Game
date: 2014-02-10 10:39
layout: post
category: post
---
Oliver Emberton on his [personal blog](http://oliveremberton.com/2014/life-is-a-game-this-is-your-strategy-guide/): 

> You might not realise, but real life is a game of strategy. There are some fun mini-games – like dancing, driving, running, and sex – but the key to winning is simply managing your resources.

> Most importantly, successful players put their time into the right things. Later in the game money comes into play, but your top priority should always be mastering where your time goes.

Fun to see certain aspects of life drawn in parallel with Role Playing Game (RPG) conventions, and the message is a poignant reminder of how important good time management skills are. 