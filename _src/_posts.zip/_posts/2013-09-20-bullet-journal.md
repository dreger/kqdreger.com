---
title: The Bullet Journal Note-Taking System
link: http://www.bulletjournal.com
date: 2013-09-20 10:20
layout: post
category: post

---
If you're like me, you love taking notes by hand. The Bullet Journal, developed by art director and designer Ryder Carroll, is a note-taking system that focuses on helping quickly collect and find all your daily todos and notes. I've been using it for the past few months and have found it to be a very personal, elegant way of organizing my daily life.

The primary place I've started using it is with my school notebooks. Numbering every page and keeping an index at the beginning of each notebook has fundamentally changed the way I take class notes. Four weeks into the semester, I'm more organized now than I've ever been before in past years. Essentially, it helps your notes become more organized over time, not less.
