---
title: A $19 Billion Partnership
date: 2014-03-18 18:03
layout: post
category: post
---
Interesting choice of words from WhatsApp founder Jan Koum [on the company's blog](http://blog.whatsapp.com/index.php/2014/03/setting-the-record-straight/): 

> If partnering with Facebook meant that we had to change our values, we wouldn't have done it. Instead, we are forming a partnership that would allow us to continue operating independently and autonomously. Our fundamental values and beliefs will not change. Our principles will not change. Everything that has made WhatsApp the leader in personal messaging will still be in place. 

I'd love to believe this is true, but given the price tag, I don't think "partnership" is right. You were acquired. Even [Zuckerberg says so](https://www.facebook.com/zuck/posts/10101272463589561). 