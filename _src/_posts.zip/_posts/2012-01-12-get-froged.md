---
layout: post
category: post
title: Get FROGED
---

In college, trying to *fully rely on God every day* is hard.

It's our first real venture into the world and the need for us to be self-sufficient is overbearing. So much so, that we often forget to rely on Him to get us through. It's easy to forget to pray when we have homework, or substitute quiet time of reflection for hanging out with friends, but none of these things help us grow spiritually.

We're surrounded by so much noise - from the TV, our friends and even ourselves can make it really hard to try and build a great relationship with God. I have to dig deep sometimes, but any time I've invested in Him has been more than rewarding to me later on. Fully rely on Him every day, for all your needs. All your insecurities, all the doubts. Go to Him.

He asks something in return though. That you share this awesome comfort with others. How come we find it easier to say "Do you want to go to Subway?" than "Do you want to go to church?". Be bold for Him and work towards spreading the love beyond yourself. Be bold.