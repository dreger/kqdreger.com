---
title: "'Summing up years of work in one sentence'"
date: 2014-01-05 16:47
layout: post
category: post
---
Incredibly funny, [one-sentence summaries of academic research papers](http://lolmythesis.com/). A great way to  kick off the new semester.