---
title: Jumping in
layout: post
category: post
date: 2013-09-02
starred: true
---
As part of my senior project, I have the unique opportunity to spend the next semester writing for this website. That's correct, I get to work on my own little web column for school credit - how awesome is that?

Stemming from a deep admiration for the [Shawn Blanc's](http://shawnblanc.net) of the world - those who jump in, feet first, to writing full-time for their websites - I'm excited to be doing just that for the next fifteen weeks. I hope to emerge a more consistent, quality writer and I look forward to building a relationship with my readers as well.

It goes without saying, I'm nervous. Some of my pieces will probably be rough around the edges, and some may never be published. However, even with these fears, I'm ready. I want to take my writing to the next level, and I'm ecstatic to have the opportunity to do just that. Let's see where these next fifteen weeks take us.

Thanks for reading,<br>
Kyle