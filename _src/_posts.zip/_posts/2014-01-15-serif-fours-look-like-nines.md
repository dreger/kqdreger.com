---
title: "Serif Fours Look a Lot Like Nines"
date: 2014-01-15 21:10
layout: post
category: post
---
Fascinating little anecdote about how _The New York Times'_ issue number [was off by 500 for more than a century](http://www.theatlantic.com/technology/archive/2014/01/the-em-new-york-times-em-had-a-mistake-on-its-front-page-every-day-for-more-than-a-century/283076/). Rebecca J. Rosen for _The Atlantic_: 

> It's easy enough to imagine the scene: A worker, late at night, setting the paper's front-page type. He takes out the type from the preceding day's paper. He looks at the issue number—14,499—and adds one. He gets 15,000.

> Perhaps he misread the number, and thought he saw 14,999 in its place. Or perhaps he'd had a long night, and just wasn't thinking straight. Who knows? What we know is that he put 15,000 as the issue number for the next day, and nobody noticed.

> And nobody noticed the next day, nor the next day, nor the next.

