---
title: John Gruber Reviews the iPhone 5C and 5S
link: http://daringfireball.net/2013/09/the_iphone_5s_and_5c
date: 2013-09-18
layout: post
category: post
 
---
If you're going to read just one review of the new iPhones, Gruber's is the one to check out. It's thorough and hits on the key features most users, not just us nerds, care about. He also makes a heartening comment about the iPhone 5C's plastic build:

> It feels slick but not slippery. Feel-wise it’s not too dissimilar from the old 3G and 3GS (both of which I still have sitting here in my office), but it presents a far more premium overall effect than those previous forays into plastic iPhones.

[Good to hear]({% post_url 2013-09-13-iphone-five-c %}).