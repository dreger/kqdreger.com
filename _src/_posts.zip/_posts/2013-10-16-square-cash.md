---
title: Square Cash
link: https://square.com/cash
date: 2013-10-16 18:35
layout: post
category: post
---
Really fascinating new service from [Square](https://square.com/) that lets you transfer money to anyone's debit card with a single email &mdash; no account required and **zero** fees. I can see college students getting tons of use out of this.