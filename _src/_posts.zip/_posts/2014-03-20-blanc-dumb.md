---
title: "'Dumb'"
date: 2014-03-20 17:20
layout: post
category: post
---
Shawn Blanc, [on the recent news regarding smartwatches](http://shawnblanc.net/2014/03/dumb/): 

> So often I'd be standing in line at the grocery store and I'd pull out my iPhone to see what time it was. Then, out of sheer habit, I'd swipe to unlock and the next thing you know I'm mindlessly scrolling through tweets or reading emails without actually acting on them. Then the line would move, I'd put the iPhone back in my pocket, and if you'd asked me what time it was I couldn't even tell you.

> My analog watches are my reminder that utility exists apart from an internet connection and usefulness doesn't require the latest software.

Usefulness doesn't require any software at all, and not all perceived "problems" are ones that need addressed by another electronic device. 