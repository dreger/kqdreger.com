---
title: We Know What You're Doing
date: 2014-01-30 10:04
layout: post
category: post
---
Callum Haywood has put together an online-privacy awareness site called [We Know What You're Doing](http://www.weknowwhatyouredoing.com/). Pulling in _public_ status updates from Facebook and Foursquare, the site groups each update into one of several categories, ranging from "who wants to get fired?" to "who's got a new phone number?" 

This site operates in similar vein to the, now defunct, [PleaseRobMe.com](http://pleaserobme.com/). PleaseRobMe pulled in public check-in data from Foursquare, alluding to the notion that if someone is checking-in to a cafe, their home is unoccupied. 

As my generation starts to make actual money at real jobs, our over-share-by-default mentality is going to come back around in a big way and getting "social hacked" will only become more common. 