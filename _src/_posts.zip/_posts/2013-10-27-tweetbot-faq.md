---
title: "Tweetbot 3 FAQ"
link: http://tapbots.com/blog/news/tweetbot-3-questions-and-answers
date: 2013-10-27 22:00
layout: post
category: post
---
Tapbots answers some questions, and hint at some upcoming features, for Tweetbot 3. Noteworthy tidbits:

- Text size is tied to iOS 7's dynamic font size in Settings.app > General > Text Size.
- A night theme is coming(!).
- Tweetbot 2 will eventually return to the App Store, but you can re-download it if you've previously purchased a copy in App Store.app > Purchased.
- Tweetbot for OS X will be getting an update to bring Mavericks compatibility in the coming weeks.