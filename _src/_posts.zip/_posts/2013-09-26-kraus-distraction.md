---
title: We're Creating a Culture of Distraction
link: http://joekraus.com/were-creating-a-culture-of-distraction
date: 2013-09-26 09:09
layout: post
category: post
 
---
Joe Kraus, writing about the growing cultural acceptance of being "distracted," and our concept of multi-tasking:

> It's shown not only that we're dumber when we do this [multi-task] (an average of 10 IQ points dumber &mdash; that's the same as pulling an all-nighter.), but that we're also 40% less efficient at whatever it is we're doing.

Twentysomethings: we really shouldn't be ignoring these trends. One of the most important contributing factors to being productive is the amount of uninterupted time you get each day. One hour of homework without your phone, internet, or TV can accomplish more than two hours of multitasking between several different things.