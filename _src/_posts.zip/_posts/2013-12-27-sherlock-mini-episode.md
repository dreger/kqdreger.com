---
title: "<em>Sherlock</em> Mini-Episode"
link: http://www.youtube.com/watch?v=JwntNANJCOE
date: 2013-12-27 13:45
layout: post
category: post
---
Until _Sherlock's_ return on January 19, this seven-minute mini-episode will have to suffice. I'm so excited for this show to come back.