---
category: link
date: 2014-04-09 12:17
layout: post
source-link: http://www.overthought.org/blog/2014/the-ultimate-guide-to-solving-ios-battery-drain
title: Solving iOS Battery Drain
---
Scotty Loveless, a former Apple Store Genius, has compiled a thorough list of things you can do to test, and increase, the battery life of your iOS devices. This part gave me a good chuckle: 

> What most people tell you is that closing your apps will save your battery life because it keeps the apps from running in the background.

> Wrong.

Nearly *everyone* I observe seems to do this. 