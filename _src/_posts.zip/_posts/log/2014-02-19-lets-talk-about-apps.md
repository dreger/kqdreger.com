---
layout: post
category: show
date: 2014-02-19 23:09
title: 001 - Let's Talk About Apps
duration: 11:12
length: 12099920
file: 2014-02-19-2309.mp3
size: 12.1MB
---
In this episode, I talk about some of the apps I'm using today and why I enjoy them. Finally, I explain some of my rational behind choosing _good_ apps, and touch on why sticking with a tool you know might be better than using the newest app on the App Store.

### Show notes
- iTunes: [Square cash](https://itunes.apple.com/us/app/square-cash/id711923939?mt=8)
- iTunes: [Messenger by Facebook](https://itunes.apple.com/us/app/facebook-messenger/id454638411?mt=8)
- iTunes: [Path](https://itunes.apple.com/us/app/path/id403639508?mt=8)
- iTunes: [VSCOcam](https://itunes.apple.com/us/app/vsco-cam/id588013838?mt=8)
- [VSCOcam on The Sweet Setup](http://thesweetsetup.com/apps/best-photo-editing-app-iphone/)
- [VSCO GRID](http://grid.vsco.co)
- [Me on VSCO GRID](http://kyledreger.vsco.co)
- [Pixel Envy by Nick Heer](http://pxlnv.com)
- [Fantastical for iPhone](https://itunes.apple.com/us/app/fantastical-2-calendar-reminders/id718043190?mt=8&uo=4&at=10ltSa) $2.99 [affiliate link]