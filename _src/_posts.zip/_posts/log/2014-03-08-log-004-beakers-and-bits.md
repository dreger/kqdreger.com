---
layout: post
category: show
date: 2014-03-08 18:41
title: 004 - Beakers and Bits
duration: 39:32
length: 33,212,008
file: 2014-03-08-1841.mp3
size: 33.2 MB
---
This week, Christopher Durr, an inorganic chemistry student and my soon-to-be brother-in-law, joins me for a relaxed talk about science and nerdery. Topics discussed: why my phone won't have 24-hour battery any time soon; the merits to the imperial system; eliminating time zones; chess; and some of our favorite apps.

### Web notes

- Chris on Twitter: [@CBDurr](https://twitter.com/cbdurr)
- [Field Notes notebooks](http://fieldnotesbrand.com)
- [Moleskine notebooks](http://www.moleskine.com/en/)
- [Bamboo Paper app](https://itunes.apple.com/us/app/bamboo-paper-notebook/id443131313?mt=8)
- [Paper by FiftyThree](http://www.fiftythree.com/paper)
- [House of Staunton Chess Boards](http://www.houseofstaunton.com) (where we got our set)
