---
layout: post
category: show
date: 2014-03-30 20:09
title: 008 - All These Games Pt. 2
duration: 33:00
length: 31,686,770
file: 2014-03-30-2009.mp3
size: 31.7 MB
---
Picking up where [part one left off]({% post_url log/2014-03-30-log-007-video-games-part-one %}), Chris and I work our way through the remaining eastern part of [our bracket](http://f.cl.ly/items/2k2X0X3H1g3o302y2H12/the-log-games-bracket.pdf).