---
layout: post
category: show
date: 2014-02-20 22:05
title: "002 - My Fiancee's Facebook"
duration: 26:57
length: 22641402
file: 2014-02-20-2205.mp3
size: 22.6MB
---
I was very pleased to have Emily Mariani, my fiancee, on the show today. Emily and I talk about Facebook Paper, the $19 billion acquisition of WhatsApp, Flappy Bird and my B+ in Geology.

### Show notes
- [Facebook Paper](https://www.facebook.com/paper)
- [The _NYT_: Facebook Enters $16 Billion Deal for WhatsApp](http://dealbook.nytimes.com/2014/02/19/facebook-to-buy-messaging-start-up/)
- [Facebook / Disney example by Kara Swisher for _Re/code_](http://recode.net/2014/02/19/facebook-price-for-having-no-phone-os-19-billion-a-must-have-apps-play-priceless/)

_Note: I accidentally called Kara Swisher "Karen" the first time I referenced her article. My apologies._

- [CNET: Penny stock Tweeter jumps 684%](http://news.cnet.com/8301-1023_3-57606103-93/oops-thanks-to-twitter-penny-stock-tweeter-jumps-684/)
- [TechCrunch: GoPro Files For IPO](http://techcrunch.com/2014/02/07/gopro-files-for-ipo-as-the-action-camera-maker-prepares-to-go-public/)
- [Facebook: 1.23 billion monthly users](http://newsroom.fb.com/Key-Facts)
- [Wikipedia: Countries by population](http://en.wikipedia.org/wiki/List_of_countries_by_population)
- [Pacific Helm](http://www.pacifichelm.com)
- [Louie Mantia's wallpapers](http://mantia.me/wallpaper/)
- [The Verge: 'Flappy Bird' racks up $50K per day in ad revenue](http://www.theverge.com/2014/2/5/5383708/flappy-bird-revenue-50-k-per-day-dong-nguyen-interview)
- [Amazon S3 hosting](http://aws.amazon.com/s3/)
- [A Small Orange hosting](http://asmallorange.com)

Some of the apps mentioned throughout the show (affiliate links):

- [Cut the Rope 2](https://itunes.apple.com/us/app/cut-the-rope-2/id681814050?mt=8&uo=4)
- [Tweetbot 3](https://itunes.apple.com/us/app/tweetbot-3-for-twitter-iphone/id722294701?mt=8&uo=4)
- [Pandora Radio](https://itunes.apple.com/us/app/pandora-radio/id284035177?mt=8&uo=4)