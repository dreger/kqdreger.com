---
layout: post
category: show
date: 2014-02-27 20:31
title: 003 - Sharpening Iron and Pencils
duration: 11:16
length: 9471342
file: 2014-02-27-2031.mp3
size: 9.5MB
---
In this episode, we talk about The Log getting submitted to iTunes; my new favorite person on Twitter, J.D. Bentley; and some thoughts and reflections on the first steps to becoming an online writer.

### Show notes
- [J.D. Bentley's website](http://jdbentley.com) and [Twitter @jdbently](https://twitter.com/jdbentley)
- [The Wired Writers Guild](http://wiredwritersguild.com/about/)
- [Proverbs 27:17](http://bible.com/1/pro.27.17.nlt)
- [Jekyll Blogging Engine](http://jekyllrb.com)
- [Quantity v. Quality anecdote](http://thewritepractice.com/quantity-v-quality/)
- [Daring Fireball](http://daringfireball.net)
- [Matt Gemmell](http://mattgemmell.com)
