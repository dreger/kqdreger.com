---
layout: post
category: show
date: 2014-03-16 21:53
title: 005 - (Interview) Dr. Rodney Dick on Web Writing
duration: 46:37
length: 39,160,351
file: 2014-03-16-2153.mp3
size: 39.2 MB
---
In this interview, I get the chance to talk with Dr. Rodney Dick, a professor of English and writing at the University of Mount Union. We take a look at whether writers *need* to understand the code behind the tools they use to publish on the web, and what it means to be a content creator in this age of ubiquitous online access. 

### Show Notes
- [Dr. Dick's @rfdphd](http://twitter.com/rfdphd)