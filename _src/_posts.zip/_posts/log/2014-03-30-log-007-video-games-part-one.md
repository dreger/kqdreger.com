---
layout: post
category: show
date: 2014-03-30 19:59
title: 007 - All These Games Pt. 1
duration: 28:48
length: 27,649,702
file: 2014-03-30-1959.mp3
size: 27.6 MB
---
Since our March Madness brackets got busted after the first round, Chris and I decided to start our own bracket &mdash; about video games.

In the first of a two-part episode, we put together our top 16 video games and work our way through the first round.

Check out the bracket [here](http://f.cl.ly/items/2k2X0X3H1g3o302y2H12/the-log-games-bracket.pdf), and give us your feedback on Twitter: [@kyledreger](http://twitter.com/kyledreger) and [@cbdurr](http://twitter.com/cbdurr).
