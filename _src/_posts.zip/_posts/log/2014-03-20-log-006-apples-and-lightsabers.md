---
layout: post
category: show
date: 2014-03-20 20:08
title: 006 - Apples and Lightsabers
duration: 53:00
length: 44,522,167
file: 2014-03-20-2008.mp3
size: 44.5 MB
---
I've had a small cold, but I'm excited to be back with co-host Chris Durr (coming in from "on location" in Columbus). We discuss some follow-up to our [last episode together]({% post_url log/2014-03-08-log-004-beakers-and-bits %}), ethanol power, Star Wars movie order, quantum computing, when our favorite shows "jumped the shark," and more. 

### Show Notes
- [The West Wing - Toby throwing the ball](http://www.youtube.com/watch?v=5G8VohYIMws)
- [Yik Yak prevents middle and high schools from accessing app](http://techcrunch.com/2014/03/13/amid-vicious-bullying-threats-of-violence-anonymous-social-app-yik-yak-shuts-off-access-to-u-s-middle-high-school-students/)
- [Flappy Bird Creator Speaks Out](http://www.rollingstone.com/culture/news/the-flight-of-the-birdman-flappy-bird-creator-dong-nguyen-speaks-out-20140311)
- [Quantum Computing](http://science.time.com/2014/02/07/quantum-computing-a-primer/)
- [D-Wave](http://www.dwavesys.com/)
- [IBM - A Boy And His Atom](http://www.research.ibm.com/articles/madewithatoms.shtml)
- [Black box](http://en.wikipedia.org/wiki/Black_box)
- ["Jumping the Shark"](http://en.wikipedia.org/wiki/Jumping_the_shark)
- [How a lightsaber works](http://dickgrune.com/Cult/LightSaber/How_a_Light_Saber_Works.html)
- [The Machete Order of watching Star Wars](http://static.nomachetejuggling.com/machete_order.html)
- [Star Wars Wikia - Lightsabers](http://starwars.wikia.com/wiki/Lightsaber)