---
title: MSNBC Has Bieber Fever
date: 2014-01-23 22:02
layout: post
category: post
---
In the middle of an interview with Congresswoman Jane Harman about the NSA, MSNBC reporter Andrea Mitchell [interrupts the congresswoman _mid-sentence_ to switch over to the "Breaking News"](https://www.youtube.com/watch?v=GH68bSJXGE8) that Justin Bieber had been arrested for a DUI. 

It's not often you see [The Onion](http://theonion.com) get beat to the punch. 