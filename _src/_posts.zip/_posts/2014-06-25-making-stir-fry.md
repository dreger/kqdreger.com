---
title: "Marriage Diary #1 - Dinner"
date: 2014-06-25 21:19
layout: post
category: post
published: false
---
We made stir fry the other night, and it didn't suck. 

But let me back up. I'm getting married next month, and I realized that, from a writing standpoint, I hold a unique perspective. The Bachelor with a Blog, before the Big day. To keep me writing, and to calm my nerves, I present the first in a series of many Marriage Diary entries. Today, it's about cooking. 

---

Like I said before: last night we made stir fry, and it didn't suck. 

Now, I would be remiss to neglect telling you that my fiancee has a fair amount of Italian in her. Not only that, but her grandmother's cooking is, quite literally, some of the best you could ever hope to eat in this life. However, correlation (my fiancee's relationship to her grandmother) does not imply causation (our dinner didn't suck), but it's nice to know that we have access to an array of delicious recipes, should we ever be able to do them justice. 

As for the actual cooking that went down the other night, I remain convinced that cooking dinner together can be one of the best ways to bond with your soon-to-be spouse. It's an activity that's *active*, you're not sitting on the couch watching Netflix; preparation can be very involved, which means having two pairs of hands makes everything easier; and you will naturally fill the brief moments of reprive from boiling water or cutting chicken with actual conversation. 

However, for as much fun as we had cooking, there are some things that are worth noting to soon-to-be-weds about the whole process: 

- You will be **amazed** at the amount of utinsels that are required, for even the most simple of recipes. 