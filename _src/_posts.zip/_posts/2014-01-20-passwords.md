---
title: The 2013 List of Worst Passwords
date: 2014-01-20 22:14
layout: post
category: post
---
SplashData, the company behind an annual "Worst Passwords" index, has [released their 2013 report](http://splashdata.com/press/worstpasswords2013.htm), listing the 25 most-used passwords on the internet. 

Notable changes from last year: "password" was usurped by "123456" for the top spot.  