---
category: link
date: 2014-05-08 18:39
layout: post
source-link: http://www.thenewsprint.co/blog/analog-markdown
title: Analog Markdown
published: false
---
My buddy Josh Ginter, over on his site _The Newsprint_:

> 