---
layout: post
category: post
title: Prepare today
---

Walking back to the dorm in the cool air tonight, I came up with a neat way of thinking about work ethic and effort:

> Prepare today so you can do tomorrow what you couldn't do yesterday.

Sounds like a quote straight out of a self-help book, but there's some real inspiration in there. Work hard to become a better, more healthy and loving person every day. Look in the mirror each night and ask yourself if you've made the world a little better. If you haven't, there's always oportunity to change that tomorrow.