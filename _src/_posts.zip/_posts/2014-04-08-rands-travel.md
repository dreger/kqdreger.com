---
title: Practical Advice for Traveling
category: link
source-link: http://randsinrepose.com/archives/practical-advice-for-the-obsessive-compulsive-traveler/
date: 2014-04-08 18:45
layout: post
---
Great stuff by Michael Lopp on being efficient and smart when traveling. As I get closer to my honeymoon, we're going out of country, I've been eating these types of articles up. 