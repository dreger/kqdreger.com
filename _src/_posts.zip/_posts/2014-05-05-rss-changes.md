---
title: Better Excerpts in RSS
date: 2014-05-05 21:44
layout: post
category: post
---
If you use my [RSS feed](/feeds) to subscribe to the site, you should begin to see a small change I implemented this week. Basically, I've added a small link (this little icon: &#10006;) to the bottom of all [excerpt posts]({% post_url 2013-12-01-meet-excerpts %}), which points back to the RSS item on kyledreger.com. 

Hopefully this helps my readers who follow along exclusively through the RSS feed. Do [let me know](/colophon). 