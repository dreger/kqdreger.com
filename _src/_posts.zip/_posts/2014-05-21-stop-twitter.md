---
category: link
date: 2014-05-21 19:37
layout: post
source-link: http://stopdesign.com/archive/2014/05/09/a-love-letter-to-twitter.html
title: Doug Bowman (@stop) to Leave Twitter
---
Doug Bowman, Twitter's Creative Director for the past five years, is leaving the company: 

> It’s a cliché in our tech industry that companies and founders start with a vision that includes the grandiose notion of changing the world. What Twitter has enabled, is enabling, and will continue to enable is nothing short of just that. As Biz says, Twitter is not a triumph of technology, it is a triumph of humanity. It all comes back to people like you and me who use the service, and what we continue to do with it. There is no other platform that offers what Twitter offers, and there is no other service that continuously reveals the collective pulse of our planet.

He will be sorely missed; Twitter has come a long way over the past five years, and Bowman was at the helm. 