---
layout: post
category: post
title: To the point
date: 2012-06-02
---

Tomorrow will be my first experience on a roller coaster.

Now sure, I've spent the better part of my childhood riding fair “rides,” but none of the holy-cow-we're-upside-down variety.

For my inaugural experience, I will be going to Cedar Point in Sandusky, Ohio. Living not too far from Cedar Point my whole life, I never really recognized what a unique place it is. Opened in 1870, it is the second oldest operating amusement park in the United States. They have a total of 16 roller coasters, most of which I assume we will be experiencing tomorrow, as well as several other attractions for the non-coaster types.

At any rate, now I'll finally be able to use the expression, “like a roller coaster” and not be a total hypocrite for never having been on one.

Special thanks to my girlfriend for setting this all up. Now here's to hoping I don't get flung off and end up in Lake Erie.