---
title: Samsung's Golden Galaxy S4
link: http://www.theverge.com/2013/9/25/4769086/samsung-counters-iphone-5s-with-a-golden-galaxy-s4
date: 2013-09-25 11:21
layout: post
category: post
 
---
The Verge:

> Two weeks after Apple's September 10th reveal of a champagne-colored iPhone, Samsung is launching its own golden phone in the shape of a new Gold Edition Galaxy S4.

You could argue the old adage that "good artist copy, great artist steal." But _extraordinary_ artists steal great features, refine them, and then implement a better version. Samsung thinks copying features is enough, continuously duplicating other competitors without adding any real value. For them, it's a race to add bullet points to a list of features.