---
category: link
date: 2014-05-24 16:57
layout: post
source-link: http://blog.agilebits.com/2014/05/23/1password-4-for-android-is-coming/
title: 1Password 4 for Android Arriving June 10
---
Good news for Android users. David Chartier: 

> All new features will be unlocked and free for everyone to use through August 1, 2014. After that, 1Password 4 for Android will go into a reader mode, and all features can be unlocked for an in-app purchase.

No coincidence that this free trial period overlaps with the Google I/O conference on June 25-26. That's the perfect time to have a new, well-respected Android app available and free. 