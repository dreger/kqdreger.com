---
title: New Site Search
date: 2013-12-27 14:13
layout: post
category: post
---
*UPDATE: Scratch that, I've removed the search for now. Until I can find a way to search in-site without punching out to Google, I'll go without.*

One of my goals with this site is to aid in both the reading and discovery of my content. To that end, I've added a search form (powered by Google) to the navigation. Although I would prefer the search be powered by [DuckDuckGo](https://duckduckgo.com), they don't have all my posts indexed, leading to incomplete search results. Feel free to try the new search out; it should make finding old posts easier than scanning my [long list in the archives](/archives).