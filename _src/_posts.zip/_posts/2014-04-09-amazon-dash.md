---
category: link
date: 2014-04-09 00:58
layout: post
source-link: https://fresh.amazon.com/dash
title: Grocery Shopping from Home
---
Amazon Dash is a new device that lets you scan the barcode on household items and have them added to your online Amazon.com or AmazonFresh shopping cart. The idea is that, as you are running low, you scan your cereal, milk, and paper towels &mdash; all of which will then be shipped to your door in a few days. 

Amazon Dash is currently only available by "invitation only," and it is unclear if it requires an AmazonFresh account, which is only open to residents of Seattle, San Francisco, or Southern California. I'd use the gadget to order household goods, but I don't know if I'd like _shipping_ food to my house. 