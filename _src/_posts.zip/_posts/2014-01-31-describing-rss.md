---
title: Describing RSS
date: 2014-01-31 21:53
layout: post
category: post
---
Since running this website is part of an academic project, I have been asked, perhaps more often than usual, to describe several of the technologies that I am using. Most non-technical people can generally grasp the idea of a statically-generated site and domains / hosting, but one topic that seems to take an extra round of explaining is RSS. 

Thankfully, Brent Simmons has a [fantastic way of explaining the protocol](http://inessential.com/2014/01/29/describing_rss), and its purpose, which I will be stealing for the future. 