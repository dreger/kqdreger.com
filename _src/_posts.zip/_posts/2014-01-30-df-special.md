---
title: "'Special'"
date: 2014-01-30 00:21
layout: post
category: post
---
Out of all the nostalgic posts regarding the Macintosh's 30th birthday, I like John Gruber's [anecdotal piece the best](http://daringfireball.net/2014/01/special): 

> For one thing, they [the original Macintosh team] sweated the details. The greatest testimony to their genius is just how much of that original design is recognizable in today’s Mac OS X 10.9. A Mac user from 1984 could sit down in front of an iMac or MacBook today and recognize it as a successor to that original machine. That’s simply amazing.



I really enjoy when Gruber opines on the business of Apple, but I think his articles about the _products_ of Apple are particularly insightful and special. 

