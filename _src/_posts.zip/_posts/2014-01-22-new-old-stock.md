---
title: New Old Stock Photography
date: 2014-01-22 18:46
layout: post
category: post
---
Cole Townsend has started curating a collection of [vintage photography from public archives](http://nos.twnsnd.co). All of the images are free of any known copyright. 

Some of my favorites include this [map of "New France"](http://www.flickr.com/photos/mississippi-dept-of-archives-and-history/10538987164/), [people being people](http://www.flickr.com/photos/nationaalarchief/9290708225/) (resist the urge to think the middle gentleman is holding a phone), and [a lettering grid](http://nos.twnsnd.co/image/71976363871) that looks oddly similar to the one used in iOS 7. 
