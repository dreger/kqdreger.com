---
category: link
date: 2014-04-30 16:11
layout: post
source-link: http://www.theverge.com/2014/4/26/5656468/comixology-ios-update-removes-in-app-purchases
published: false
title: Comixology Removes In-App Purchases from iOS App
---
Eight days after Beats Music starts [selling subscriptions through Apple's in-app purchase dialogue]({% post_url 2014-04-21-beats-in-app %}), Comixology does the exact opposite, removing the option to purchase comics from inside their app. 



[Amazon aquired Comixology](http://www.theverge.com/2014/4/10/5602222/amazon-acquiring-digital-comics-platform-comixology), a digital comics 