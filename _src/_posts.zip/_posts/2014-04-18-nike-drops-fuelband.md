---
category: link
date: 2014-04-18 22:20
layout: post
source-link: http://www.cnet.com/news/nike-fires-fuelband-engineers-will-stop-making-wearable-hardware/
title: Nike Drops the FuelBrand
published: false
---
Testin