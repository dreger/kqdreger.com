---
title: "Nike+ Move"
link: "https://itunes.apple.com/us/app/nike+-move/id712498492"
date: 2013-11-04 21:43
layout: post
category: post
---
Apple and Nike have always had a good relationship (remember the [Nike + iPod Sport Kit](http://www.pcmag.com/article2/0,2817,1989319,00.asp)?) so it's little surprise that one of the first "big" apps to take advantage of the 5S's new activity-monitoring M7 processor is from Nike.

I do wonder how much longer this relationship will last, however, given that Nike has a [whole line of wrist wear](http://www.nike.com/us/en_us/c/nikeplus-fuelband) designed to do the M7's job _without_ an iPhone. Things will get interesting if Apple ever does enter into the wearable-computing game.