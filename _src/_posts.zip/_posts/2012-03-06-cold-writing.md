---
Title: Cold writing
layout: post
category: post
comments: true
---

I've found that as I write papers for class, sometimes I hit a wall. This isn't a full case of writers block, rather I feel the enthusiasm start to fade. What was just a feverish output of thoughts to typed characters is starting to die. Eventually, I've stopped writing and am looking at my cursor blink. Blink. Blink. Blink.

This is when I hit Command + "N" and open up a new document. Without thinking more than a few seconds, I start "cold" writing about anything I want. Stacking wood, running in the snow, listening to instrumental music - anything that comes to mind. The block is gone, my writing flame has recaptured it's intensity and I'm having fun. I'll pound out 500 words on this new topic in the time it took me to get 200 for the first one.

When I'm done, I return to my original document. Every single time I do, the writers block is gone and I get back to typing. This sort of "cold writing" to jumpstart my spirit is a great exercise. I don't do it every time I write a paper, however once or twice throughout the course of a longer essay is normal. I'm not worried about the time I lose when doing these short side-articles; the small amount of time I invest to reset my thoughts and come back focused is well worth it.

Some of my ideas for blog posts have come from cold writing. In fact, this post you're reading was being written as I worked on a paper assigned for when I get back from spring break. Writing to get rid of writer's block, go figure.